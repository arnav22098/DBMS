Online Shopping System README
Overview:
This Python project implements an online shopping system where users can browse products, add them to a cart, and proceed with checkout. It includes features like login authentication, product category filtering, order placement, and customer analysis.

Contributors:
Dikshant-did the front-end 
Arnav- design the layers and did the backend and front end
Snigdha-helped in debugging 
Project Structure:
main.py: Main script to run the online shopping system.
sqlite_database.db: SQLite database file containing product, customer, order, and transaction information.
README.md: This documentation file.
Functionality:
Login: Users can log in using their name and phone number.
Browse Products: Users can browse products by category and view details such as name, price, and quantity.
Add to Cart: Users can add products to their cart and specify the quantity.
Checkout: Users can proceed with the checkout process, including selecting payment methods and confirming orders.
Customer Analysis: Admins can view customer purchase history, spending, and product preferences.
How to Run:
Ensure Python and SQLite are installed.
Run main.py to start the online shopping system.
Follow the on-screen instructions to navigate through the system.
Dependencies:
Python 3.x
SQLite 3.x
Future Improvements:
Implement user registration functionality.
Enhance product search and filtering options.
Add real-time order tracking features.
Improve error handling and user feedback.